//
//  DummyString.swift
//  
//  Copyright © 2020 Apple Inc. All rights reserved.
//

import Foundation
var s1 = NSLocalizedString("dummy string", comment: "just string to stop our build script from whining")
